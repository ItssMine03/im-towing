fx_version 'cerulean'
game 'gta5'

version '1.0.2'

client_scripts {
    "config.lua",
    "client.lua"
}